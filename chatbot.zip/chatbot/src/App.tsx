import { useContext } from "react";
import {
  Send,
  Plus,
  Search,
  Settings,
  Moon,
  MessageSquare,
} from "lucide-react";
import { ChatContext } from "./context/ChatProvider";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import 'react-toastify/dist/ReactToastify.css';
import { toast, ToastContainer } from "react-toastify";
const App: React.FC = () => {
  const chatContext = useContext(ChatContext);

  if (!chatContext) {
    return <div>Loading...</div>;
  }

  const {
    messages,
    chatHistory,
    searchQuery,
    setSearchQuery,
    handleSend,
    setInput,
    input,
    setMessages,
    loading,
    errorMessage,
    setChatId,
    setNewChatClicked,
    chatClicked,
    handleDelete,
  } = chatContext;
  console.log(chatClicked,errorMessage,loading);

  // if (loading) {
  //   return <Loading />;
  // }
  return (
    <div className="h-screen bg-gray-50">
      <div className="flex h-full">
        <div className="w-80 bg-white border-r border-gray-200">
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                  <MessageSquare size={20} className="text-white" />
                </div>
                <h1 className="text-xl font-semibold">ASR Business Analyst</h1>
              </div>
              <div className="flex space-x-2">
                <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-full">
                  <Moon size={20} />
                </button>
                <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-full">
                  <Settings size={20} />
                </button>
              </div>
            </div>
            <button
              // onClick={handleNewChat}
              onClick={() => {
                setNewChatClicked(true);
                setMessages({
                  id: null,
                  sender: "ai",
                  timestamp: new Date().toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  }),
                  messages: [],
                });
                toast.success("New Conversation has been clicked!", {
                  position: "top-right",
                  autoClose: 3000, // Duration of the notification in ms
                });
              }}
              className="flex items-center justify-center w-full p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-md"
            >
              <Plus size={20} className="mr-2" /> New Conversation
            </button>
            <ToastContainer position="top-right" autoClose={3000} hideProgressBar={false} />

          </div>
          <div className="p-4 border-b border-gray-200">
            <div className="relative">
              <Search
                size={20}
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
              />
              <input
                type="text"
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="overflow-y-auto h-[calc(100vh-240px)]">
              {chatHistory
                .filter(
                  (chat) =>
                    chat.title
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase()) ||
                    chat.preview
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase())
                )
                .map((chat) => (
                  <div
                    key={chat.id}
                    onClick={() => {
                      setMessages(chatHistory.find((i) => i.id == chat.id)),
                        setChatId(chat.id);
                    }}
                    className="p-4 hover:bg-gray-50 cursor-pointer border-b border-gray-100 transition-colors"
                  >
                    <div className="flex justify-between items-start mb-1">
                      <h3 className="font-medium text-gray-900">
                        {chat.preview}
                      </h3>
                      <span className="text-xs text-gray-500">
                        {chat.timestamp}
                      </span>
                    </div>
                    <div className="w-full flex justify-end">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(chat.id);
                        }}
                        className="ml-4 px-2 py-1 bg-red-500 text-white text-xs rounded hover:bg-red-600  "
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>

        <div className="flex-1 flex flex-col bg-white">
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((msg: any, index: any) => (
              <div
                key={index}
                className={`flex ${
                  msg.sender === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-[70%] p-4 rounded-lg shadow-sm ${
                    msg.sender === "user"
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-800"
                  }`}
                >
                  <ReactMarkdown
                    className="text-sm"
                    remarkPlugins={[remarkGfm]}
                    components={{
                      strong: ({ children }) => (
                        <strong className="font-bold">{children}</strong>
                      ),
                      ul: ({ children }) => (
                        <ul className="list-disc pl-5">{children}</ul>
                      ),
                      ol: ({ children }) => (
                        <ol className="list-decimal pl-5">{children}</ol>
                      ),
                      table: ({ children }) => (
                        <table className="table-auto border-collapse w-full mt-2">
                          {children}
                        </table>
                      ),
                      th: ({ children }) => (
                        <th className="border px-4 py-2 bg-gray-200">
                          {children}
                        </th>
                      ),
                      td: ({ children }) => (
                        <td className="border px-4 py-2">{children}</td>
                      ),
                    }}
                  >
                    {msg.text}
                  </ReactMarkdown>
                  <div
                    className={`text-xs mt-1 ${
                      msg.sender === "user" ? "text-white" : "text-gray-500"
                    } `}
                  >
                    {msg.timestamp}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 border-t border-gray-200 flex items-center">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && input.trim() !== "") {
                  handleSend(input);
                  setInput("");
                }
              }}
              placeholder="Type a message..."
              className="flex-1 p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            <button
              onClick={() => {
                handleSend(input);
                setInput("");
              }}
              className="ml-2 p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </div>

    </div>
  );
};

export default App;
