
export const Loading: React.FC = () => {
    return (
      <div className="flex justify-center items-center h-screen bg-gray-50">
        <div className="text-lg font-semibold text-gray-600">Loading...</div>
      </div>
    );
  };
  