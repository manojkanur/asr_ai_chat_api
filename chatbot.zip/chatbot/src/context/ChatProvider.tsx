import { createContext, useEffect, useState } from "react";

interface Chat {
  id: string;
  title: string;
  preview: string;
  timestamp: string;
  messages: any;
}

interface ChatContextType {
  messages: any;
  chatHistory: Chat[];
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  handleSend: (input: string) => void;
  handleNewChat: () => void;
  setInput: any;
  input: any;
  setMessages: any;
  loading: any;
  errorMessage: string;
  setChatId: any;
  setNewChatClicked:any;
  chatClicked:any;
  handleDelete:any
}

export const ChatContext = createContext<ChatContextType | undefined>(
  undefined
);

export const ChatProvider = ({ children }: any) => {
  const [chatId, setChatId] = useState<string | null>(null);
  const [chatHistory, setChatHistory] = useState<Chat[]>([]);
  const [messages, setMessages] = useState<any>({
    id: null,
    sender: "ai",
    timestamp: new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    }),
    messages: [],
  });

  const [errorMessage, setErrorMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [input, setInput] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [chatClicked,setNewChatClicked] = useState(false)

  // Load chat history from localStorage on mount
  useEffect(() => {
    const savedChatHistory = localStorage.getItem("chatHistory");
    if (savedChatHistory) {
      setChatHistory(JSON.parse(savedChatHistory));
    }
  }, []);


  const handleSend = async (input: string) => {
    if (!input.trim()) return;

    const userMessage = {
      sender: "user",
      text: input,
      timestamp: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
    };

    const loadingMessage = {
      sender: "ai",
      type: "dummy",
      text: "🤖 AI is typing...",
      timestamp: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
    };

    setMessages((prev: any) => ({
      ...prev,
      messages: [...prev.messages, userMessage, loadingMessage],
    }));

    try {
      setLoading(true);
      const requestBody: any = { message: input };
      if (chatId) {
        requestBody.chat_id = chatId;
      }

      const aiResponse = await fetch("http://127.0.0.1:5000/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestBody),
      });

      const aiData = await aiResponse.json();
      if (!aiData || !aiData.response) {
        throw new Error("Invalid response from AI");
      }

      setMessages((prev: any) => ({
        messages: prev.messages.filter((msg: any) => msg.type !== "dummy"),
      }));
      if(chatClicked == true){
        handleNewChat()
      }
      if (!chatId && aiData.chat_id) {

        setChatId(aiData.chat_id);
      }
      
      const aiMessage = {
        sender: "ai",
        text: aiData.response,
        timestamp: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        }),
      };
      
      setMessages((prev: any) => ({
        ...prev,
        id: prev.chat_id || aiData.chat_id,
        messages: [...prev.messages, aiMessage],
      }));

      setChatHistory((prev) => {
        const updatedHistory = prev.map((chat) =>
          String(chat.id) === messages.id
            ? { ...chat, messages: [...chat.messages, userMessage, aiMessage] }
            : chat
        );

        localStorage.setItem("chatHistory", JSON.stringify(updatedHistory));
        return updatedHistory;
      });
      setNewChatClicked(false)
    } catch (error) {
      setErrorMessage("Error from server");
      console.error("Error sending message:", error);
    } finally {
      setLoading(false);
    }
  };
  const handleDelete = (id:any) => {
    console.log(id,chatHistory)
    setChatHistory((prev) => {
      const updatedHistory = prev.filter((chat) => chat.id !== id);
      localStorage.setItem("chatHistory", JSON.stringify(updatedHistory));
      return updatedHistory;
    });
  };
  const handleNewChat = async () => {
    const newChat = {
      id: String(Date.now()),
      title: "New Conversation",
      preview: "",
      timestamp: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
      messages: [],
    };
  
    setMessages(newChat);
    setChatHistory((prev) => [newChat, ...prev]);
  
    try {
      setLoading(true);
      const aiResponse = await fetch("http://127.0.0.1:5000/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: "hi" }),
      });
  
      const aiData = await aiResponse.json();
      setLoading(false);
  
      if (!chatId && aiData.chat_id) {
        setChatId(aiData.chat_id);
      }
  
      if (aiData?.chat_id) {
        const aiMessage = {
          sender: "ai",
          text: aiData.response,
          timestamp: new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          }),
        };
  
        // Generate preview (first 20 characters of the AI response)
        const previewText = input.substring(0, 20);
  
        setMessages((prev: any) => ({
          ...prev,
          id: aiData.chat_id,
          messages: [aiMessage],
          preview: previewText,
        }));
  
        setChatHistory((prev) => {
          const updatedHistory = prev.map((chat) =>
            String(chat.id) === newChat.id
              ? { ...chat, id: aiData.chat_id, messages: [aiMessage], preview: previewText }
              : chat
          );
  
          localStorage.setItem("chatHistory", JSON.stringify(updatedHistory));
          return updatedHistory;
        });
      }
    } catch (error) {
      setErrorMessage("Error starting a new chat.");
      setLoading(false);
    }
  };
  

  useEffect(() => {
    if (chatId) {
      fetchChatHistory(chatId);
    }
  }, [chatId]);

  const fetchChatHistory = async (id: string) => {
    try {
      setLoading(true);
      const response = await fetch(`http://127.0.0.1:5000/chat_history/${id}`);
      if (!response.ok) throw new Error("Failed to fetch chat history");

      const data = await response.json();
      setMessages({
        id: data.chat_id,
        sender: "ai",
        timestamp: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        }),
        messages: data.history.map((msg: any) => ({
          sender: msg.role === "HumanMessage" ? "user" : "bot",
          text: msg.content,
          timestamp: new Date().toLocaleTimeString(),
        })),
      });

      setChatHistory((prev) => {
        const updatedHistory = prev.map((chat) =>
          String(chat.id) === data.chat_id
            ? { ...chat, messages: data.history }
            : chat
        );

        localStorage.setItem("chatHistory", JSON.stringify(updatedHistory));
        return updatedHistory;
      });
    } catch (error: any) {
      setErrorMessage(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ChatContext.Provider
      value={{
        messages: messages?.messages || [],
        chatHistory,
        searchQuery,
        setSearchQuery,
        handleSend,
        handleNewChat,
        setInput,
        input,
        setMessages,
        loading,
        errorMessage,
        setChatId,
        setNewChatClicked,
        chatClicked,
        handleDelete
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};
